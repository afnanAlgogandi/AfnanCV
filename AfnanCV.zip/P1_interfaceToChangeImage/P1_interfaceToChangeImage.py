import cv2
import numpy as np
import tkinter as tk
from tkinter import filedialog
from PIL import Image, ImageTk



# Create a Tkinter window
window = tk.Tk()



# Difine colors
bgColor = "Lavender"
textColor = "white"
frameColor = "#CCCCFF"



# Set the window properties
window.title("AfnanCV")
window.config(bg=bgColor)
window.geometry("900x600")
window.maxsize(900, 600)



#load image icons
uploadIcon = Image.open("upload.png")
uploadIcon = uploadIcon.resize((40, 40))
uploadIcon = ImageTk.PhotoImage(uploadIcon)

saveIcon = Image.open("download.png")
saveIcon = saveIcon.resize((40, 40))
saveIcon = ImageTk.PhotoImage(saveIcon)

resetIcon = Image.open("reset.png")
resetIcon = resetIcon.resize((40, 40))
resetIcon = ImageTk.PhotoImage(resetIcon)

blurIcon = Image.open("blur.png")
blurIcon = blurIcon.resize((40, 40))
blurIcon = ImageTk.PhotoImage(blurIcon)

flipIcon = Image.open("flip.png")
flipIcon = flipIcon.resize((40, 40))
flipIcon = ImageTk.PhotoImage(flipIcon)

grayIcon = Image.open("gray_icon.png")
grayIcon = grayIcon.resize((40, 40))
grayIcon = ImageTk.PhotoImage(grayIcon)

resizeIcon = Image.open("resize.png")
resizeIcon = resizeIcon.resize((40, 40))
resizeIcon = ImageTk.PhotoImage(resizeIcon)

rotateIcon = Image.open("rotation.png")
rotateIcon = rotateIcon.resize((40, 40))
rotateIcon = ImageTk.PhotoImage(rotateIcon)



#creat frames, left to hold tools, right to hols image
left_frame = tk.Frame(window, width=65, height=600, bg=frameColor)
left_frame.place_forget()

right_frame = tk.Frame(window, width=700, height=400, bg=frameColor)
right_frame.place_forget()



#load the logo image
afnanCV_logo = Image.open("AfnanCV_logo.png")
afnanCV_logo = afnanCV_logo.resize((75, 55))
afnanCV_logo = ImageTk.PhotoImage(afnanCV_logo)
logo_label1 = tk.Label(window, image=afnanCV_logo, highlightthickness=0, borderwidth=0, bg=bgColor)
logo_label1.place(x=820, y=535)

EVC_image = Image.open("EVC_logo.png")
EVC_image = EVC_image.resize((90, 60))
EVC_logo = ImageTk.PhotoImage(EVC_image)
logo_label2 = tk.Label(window, image=EVC_logo, highlightthickness=0, borderwidth=0, bg=bgColor)
logo_label2.place(x=800, y=3)



#Create a labels
welcome_label = tk.Label(window, text="Welcome to AfnanCV", font=("OCR", 41), justify="center", bg=bgColor, fg="black")
welcome_label.place(x=176, y=192)

subWelcome_label = tk.Label(window, text="Get ready to experience image processing\n like never before", font=("Arial", 15), justify="center", bg=bgColor, fg="black")
subWelcome_label.place(x=250, y=290)

photo_label = tk.Label(right_frame)
photo_label.place_forget()



# Define a global variable to hold the selected image
global_img = None
original_img = None



def showImage(photo):
    # Convert the photo to a NumPy array
    photo = np.array(photo)

    # Convert the color space from BGR to RGB
    photo = cv2.cvtColor(photo, cv2.COLOR_BGR2RGB)

    # Convert the NumPy array back to an image
    image = Image.fromarray(photo)

    # Convert the image to a PhotoImage object
    photo_image = ImageTk.PhotoImage(image)

    # Update the label with the new image
    photo_label.config(image=photo_image)
    photo_label.image = photo_image



#update the visibility of the window's elements after uploading the image
def showButtons():
    left_frame.place(x=0, y=0)
    right_frame.place(x=130, y=100)

    resize_button.place(x=12, y=120)
    gray_button.place(x=12, y=195)
    rotate_button.place(x=12, y=270)
    flip_button.place(x=12, y=345)
    blur_button.place(x=12, y=420)
    reset_button.place(x=350, y=520)
    save_button.place(x=490, y=520)

    welcome_label.place_forget()
    subWelcome_label.place_forget()
    photo_label.place(x=7, y=7)



def select_photo():
    global global_img, original_img
    # Open a file dialog box to select a photo
    file_path = filedialog.askopenfilename()

    # Load the selected photo using PIL
    photo = cv2.imread(file_path)

    # Resize the photo to fit in the label
    photo = cv2.resize(photo, (680, 380))

    original_img = photo
    global_img = photo

    showImage(global_img)
    showButtons()



def Resize(my_img):
    global global_img

    # Create a Toplevel window for resizing
    resize_window = tk.Toplevel(window)
    resize_window.title("Resize Image")

    # Create a Scale widget for the height
    height_label = tk.Label(resize_window, text="Height:")
    height_label.pack()
    height_scale = tk.Scale(resize_window, from_=1, to=380, orient=tk.HORIZONTAL)
    height_scale.pack()

    # Create a Scale widget for the width
    width_label = tk.Label(resize_window, text="Width:")
    width_label.pack()
    width_scale = tk.Scale(resize_window, from_=1, to=680, orient=tk.HORIZONTAL)
    width_scale.pack()

    # Create a button to resize the image
    resize_button = tk.Button(resize_window, text="Resize", command=lambda: do_resize(height_scale.get(), width_scale.get()))
    resize_button.pack()


    # Function to resize the image based on the selected height and width
    def do_resize(height, width):
        global global_img

        # Resize the image
        resized_img = cv2.resize(my_img, (width, height))

        global_img = resized_img
        showImage(global_img)

        # Close the resize window
        resize_window.destroy()



def gray(my_img):
    global global_img

    # Convert the image to grayscale
    gray_img = cv2.cvtColor(my_img, cv2.COLOR_BGR2GRAY)

    global_img = gray_img
    showImage(global_img)



def rotate(my_img):
    global global_img

    # Rotate the image by 90 degrees
    rotated_img = cv2.rotate(my_img, cv2.ROTATE_90_CLOCKWISE)

    global_img = rotated_img
    showImage(global_img)



def flip(my_img):
    global global_img

    # Flip the image horizontally
    flipped_img = cv2.flip(my_img, 1)

    global_img = flipped_img
    showImage(global_img)



def blur(my_img):
    global global_img

    # Convert the image to a numpy array
    img_array = np.array(my_img)

    # Apply a Gaussian blur to the image
    blurred_array = cv2.GaussianBlur(img_array, (5, 5), 0)

    global_img = blurred_array
    showImage(global_img)


def reset():
    global global_img, original_img
    global_img = original_img
    showImage(global_img)


def save():
    global global_img

    try:
        # Save the modified image
        save_path = filedialog.asksaveasfilename(defaultextension=".png")
        cv2.imwrite(save_path, global_img)

        save_label = tk.Label(window, text="image saved successfully", fg="black", bg='lightgreen')
        save_label.place(x=400, y=10)

    except:
        save_label = tk.Label(window, text="error, try again!", fg="black", bg='red')
        save_label.place(x=400, y=10)

    finally:
        window.after(5000, lambda: save_label.place_forget())



# Create a button to select a photo
select_button = tk.Button(window, image=uploadIcon, text="Select Photo", command=select_photo, bg=bgColor, highlightthickness=0, borderwidth=0)
select_button.place(x=420, y=520)


# Create buttons to apply image processing functions
resize_button = tk.Button(left_frame, image=resizeIcon, command=lambda: Resize(global_img), bg=frameColor, highlightthickness=0, borderwidth=0)
resize_button.place_forget()

gray_button = tk.Button(left_frame, image=grayIcon, command=lambda: gray(global_img), bg=frameColor, highlightthickness=0, borderwidth=0)
gray_button.place_forget()

rotate_button = tk.Button(left_frame, image=rotateIcon, command=lambda: rotate(global_img), bg=frameColor, highlightthickness=0, borderwidth=0)
rotate_button.place_forget()

flip_button = tk.Button(left_frame, image=flipIcon, command=lambda: flip(global_img), bg=frameColor, highlightthickness=0, borderwidth=0)
flip_button.place_forget()

blur_button = tk.Button(left_frame, image=blurIcon, command=lambda: blur(global_img), bg=frameColor, highlightthickness=0, borderwidth=0)
blur_button.place_forget()

reset_button = tk.Button(window, image=resetIcon, command=reset, bg=bgColor, highlightthickness=0, borderwidth=0)
reset_button.place_forget()

save_button = tk.Button(window, image=saveIcon, command=save, bg=bgColor, highlightthickness=0, borderwidth=0)
save_button.place_forget()



# Run the Tkinter event loop
window.mainloop()


